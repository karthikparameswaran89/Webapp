from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib import messages
from django.db import connection
from .forms import LoginForm


def index(request):
    if 'gpn' in request.session:
        return render(request, 'index.html') 
    return redirect('login')

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            gpn = form.cleaned_data['gpn']
            #password = form.cleaned_data['password']
            
            # Raw SQL query to check credentials
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM Login_Details WHERE gpn = %s ", [gpn])
                user = cursor.fetchone()
                
            if user:
                # Assuming user authentication is successful
                request.session['gpn'] = gpn
                return redirect('index')
            else:
                messages.error(request, 'Invalid User gpn')
    else:
        form = LoginForm()
    
    return render(request, 'login.html', {'form': form})


def profile_view(request):
    # Retrieve the gpn from the session (assuming it's set during login)
    gpn = request.session.get('gpn')
    
    if not gpn:
        # Redirect to login if user is not authenticated
        return redirect('login')
    
    if request.method == 'POST':
        # Handle skill form submission
        skill_id = request.POST.getlist('skill_id')
        skill_names = request.POST.getlist('skill_name')
        experiences = request.POST.getlist('experience')
        active_skills = request.POST.getlist('active_skill')
        
        with connection.cursor() as cursor:
            # Delete selected skills
            for skill_id in skill_id:
                cursor.execute("""
                    DELETE FROM SKILL_DETAILS
                    WHERE skill_name = %s and gpn=%s
                """, [skill_id,gpn])
            
            # Insert or update skill details
            for skill_name, experience, active_skill in zip(skill_names, experiences, active_skills):
                if skill_name:  # Check if skill_name is not empty
                    cursor.execute("""
                        INSERT INTO SKILL_DETAILS (gpn, SKILL_NAME, EXPERIENCE, ACTIVE_SKILL)
                        VALUES (%s, %s, %s, %s)
                    """, [gpn, skill_name, experience, active_skill])
            messages.success(request, 'Skills updated successfully')
        
        return redirect('profile')

    # Fetch user profile data from the database
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT GPN, FIRST_NAME, LAST_NAME, EMPLOYEE_LOCATION, COST_CENTRE, WORK_EXPERIENCE, CASE WHEN INTERESTED_IN_CHANGE=1 THEN 'YES' ELSE 'NO' END INTERESTED_IN_CHANGE
            FROM employee
            WHERE gpn = %s
        """, [gpn])
        profile_data = cursor.fetchone()
    
    if not profile_data:
        # Handle case where no profile data is found
        return render(request, 'profile.html', {'error': 'Profile not found'})
    
    # Map the profile data to a dictionary for easier access in the template
    profile = {
        'GPN': profile_data[0],
        'FIRST_NAME': profile_data[1],
        'LAST_NAME': profile_data[2],
        'EMPLOYEE_LOCATION': profile_data[3],
        'COST_CENTRE': profile_data[4],
        'WORK_EXPERIENCE': profile_data[5],
        'INTERESTED_IN_CHANGE': profile_data[6],
    }

    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT SKILL_NAME, EXPERIENCE, ACTIVE_SKILL
            FROM SKILL_DETAILS
            WHERE gpn = %s
        """, [gpn])
        skills_data = cursor.fetchall()
    
    skills = [{'SKILL_NAME': row[0], 'EXPERIENCE': row[1], 'ACTIVE_SKILL': row[2]} for row in skills_data]
    
    
    return render(request, 'profile.html', {'profile': profile, 'skills': skills})