document.addEventListener('DOMContentLoaded', function() {
    const addSkillButton = document.getElementById('add-skill');
    const skillFieldsContainer = document.getElementById('skill-fields');

    addSkillButton.addEventListener('click', function() {
        const skillEntry = document.createElement('div');
        skillEntry.className = 'skill-entry';
        
        skillEntry.innerHTML = `
            <label for="skill_name">Skill Name:</label>
            <input type="text" name="skill_name" class="skill_name" required>
            <label for="experience">Experience:</label>
            <input type="text" name="experience" class="experience" required>
            <label for="active_skill">Active Skill:</label>
            <input type="checkbox" name="active_skill" class="active_skill">
        `;
        
        skillFieldsContainer.appendChild(skillEntry);
    });
});